package com.capg.srj.springrestjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
