package com.capg.srj.springrestjpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.srj.springrestjpa.beans.Stock;

public interface StockRepository extends JpaRepository<Stock, Integer>{

}
