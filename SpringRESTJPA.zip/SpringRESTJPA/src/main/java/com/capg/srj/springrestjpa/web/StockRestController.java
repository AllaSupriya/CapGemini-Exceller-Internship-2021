package com.capg.srj.springrestjpa.web;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.srj.springrestjpa.beans.Stock;
import com.capg.srj.springrestjpa.beans.Transaction;
import com.capg.srj.springrestjpa.services.StockTransService;

import io.swagger.annotations.Api;

@Validated
@RestController
@RequestMapping("/api")
public class StockRestController {

	@Autowired 
	private StockTransService service;

	@GetMapping("/home")
	public String homeRequest() {
		return "Welcome : My Stock App "+LocalDateTime.now();
	}
	
	@PostMapping("/trans")
	public Transaction insertProduct(@RequestBody Transaction trans) {
		service.postStockData(trans);
		return trans;
	}
	
	@GetMapping("/trans")
	public List<Transaction> getAllTrans() {
		return service.getAllTransactions();
	}

	@GetMapping("/stocks")
	public List<Stock> getAllStock(){
		return service.getAllStocks();
	}

	@GetMapping("/transaction/{id}")
	public Transaction getProductById(@PathVariable int id) {
		return service.getTransactionById(id);

	}

	@PostMapping("/stock/{stockName}/{stockPrice}/{transactionType}")
	private Transaction postData(@PathVariable String stockName, int stockPrice, String transactionType) {
		return service.postTransactionData(stockName,stockPrice,transactionType);
	}


}
