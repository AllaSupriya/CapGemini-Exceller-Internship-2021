package com.capg.srj.springrestjpa.services;

import java.util.*;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.srj.springrestjpa.beans.Stock;
import com.capg.srj.springrestjpa.beans.Transaction;
import com.capg.srj.springrestjpa.dao.StockRepository;
import com.capg.srj.springrestjpa.dao.TransactionRepository;

@Service
public class StockServiceImpl implements StockTransService{
	
	@Autowired
	StockRepository srepo;
	
	@Autowired
	TransactionRepository trepo;
	
	@Override
	public List<Stock> getAllStocks() {
		return srepo.findAll();
	}

	@Override
	public List<Transaction> getAllTransactions() {
		return trepo.findAll();
	}

	@Override
	public Transaction getTransactionById(int id) {
		// TODO Auto-generated method stub
		return trepo.findById(id).get();
	}

	@Override
	@Transactional
	public Transaction postTransactionData(String stockName, int stockPrice, String transactionType) {
		List<Stock> os = srepo.findAll();
		
		
		return null;
	}

	@Override
	public Transaction postStockData(Transaction s) {
		trepo.save(s);
		return s;
	}

}
