package com.capg.srj.springrestjpa.services;

import java.util.List;

import com.capg.srj.springrestjpa.beans.Stock;
import com.capg.srj.springrestjpa.beans.Transaction;

public interface StockTransService {

	public List<Stock> getAllStocks();

	public List<Transaction> getAllTransactions();

	public Transaction getTransactionById(int id);

	public Transaction postTransactionData(String stockName, int stockPrice, String transactionType);

	public Transaction postStockData(Transaction s);

}
